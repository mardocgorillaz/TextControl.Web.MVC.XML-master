# Asp.Net-MVC-PartialView-Ajax-Sample
Asp.Net MVC PartialView Ajax Sample

Build as Visual Studio 2015
